$sourceFolder = "C:\postify\posts"

Get-ChildItem "$sourceFolder\*.xml" | ForEach-Object {
    $taskPath = $_.FullName
    $taskName = ($_.BaseName -replace "_", "\")  # שחזור שם המשימה

    # קובץ זמני להורדת המשימה הקיימת
    $tempExport = "$env:TEMP\existing_task.xml"

    # בדיקת קיום משימה
    schtasks /Query /TN "$taskName" /XML > $null 2>&1
    if ($LASTEXITCODE -eq 0) {
        schtasks /Query /TN "$taskName" /XML > $tempExport

        # השוואת HASH בין המשימות
        $newHash = Get-FileHash -Algorithm SHA256 $taskPath
        $oldHash = Get-FileHash -Algorithm SHA256 $tempExport

        if ($newHash.Hash -ne $oldHash.Hash) {
            Write-Host "🔄 Updating task: $taskName"
            schtasks /Create /TN "$taskName" /XML "$taskPath" /F
        } else {
            Write-Host "✅ Task up-to-date: $taskName"
        }

        Remove-Item $tempExport -Force
    } else {
        Write-Host "➕ Creating new task: $taskName"
        schtasks /Create /TN "$taskName" /XML "$taskPath"
    }
}
