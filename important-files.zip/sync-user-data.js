const fs = require("fs");
const path = require("path");
const https = require("https");
const { sendMail, sendErrorMail } = require("./mailer");

// 🧠 קרא את שם השרת מתוך הקובץ instance-name.txt
const instanceNameFile = path.join(__dirname, "instance-name.txt");
if (!fs.existsSync(instanceNameFile)) {
  console.error("❌ Missing instance-name.txt");
  process.exit(1);
}
const hostname = fs.readFileSync(instanceNameFile, "utf-8").trim();

// הגדרת התיקייה של הלקוח
const userFolder = path.join("C:", "postify", "user data", hostname);
const apiUrl = `https://postify.co.il/wp-content/postify-api/get-user-data.php?hostname=${hostname}`;

// מערכת לוגים
let logMessages = [];
const logFile = path.join(userFolder, "sync-log.txt");

function logMessage(level, message) {
  const timestamp = new Date().toISOString().replace('T', ' ').split('.')[0];
  const logEntry = `[${timestamp}] ${level}: ${message}`;
  logMessages.push(logEntry);
  console.log(`${level === 'ERROR' ? '❌' : level === 'WARN' ? '⚠️' : 'ℹ️'} ${message}`);
}

function saveLogToFile() {
  try {
    fs.mkdirSync(path.dirname(logFile), { recursive: true });
    const logContent = logMessages.join('\n') + '\n';
    fs.writeFileSync(logFile, logContent, 'utf-8');
    console.log(`📋 לוג נשמר ב: ${logFile}`);
  } catch (error) {
    console.error(`❌ שגיאה בשמירת לוג: ${error.message}`);
  }
}

// ========== פונקציות סינכרון חכם ==========
function getRemoteFileSize(url) {
  return new Promise((resolve, reject) => {
    https.request(url, { method: 'HEAD' }, (response) => {
      if (response.statusCode !== 200) {
        return reject(new Error(`Status ${response.statusCode} for ${url}`));
      }
      const contentLength = response.headers['content-length'];
      resolve(contentLength ? parseInt(contentLength) : null);
    }).on('error', reject).end();
  });
}

function isFileIdentical(localPath, remoteUrl) {
  return new Promise(async (resolve) => {
    try {
      if (!fs.existsSync(localPath)) {
        return resolve(false);
      }
      
      const localStats = fs.statSync(localPath);
      const localSize = localStats.size;
      
      // אם הקובץ המקומי ריק או קטן מדי, הוא כנראה לא תקין
      if (localSize < 100) {
        logMessage('WARN', `קובץ מקומי קטן מדי (${localSize} bytes): ${path.basename(localPath)}`);
        return resolve(false);
      }
      
      const remoteSize = await getRemoteFileSize(remoteUrl);
      if (remoteSize && Math.abs(localSize - remoteSize) <= 100) {
        // הקבצים זהים בגודל (עם סובלנות של 100 bytes)
        logMessage('INFO', `קובץ זהה נמצא, מדלג: ${path.basename(localPath)} (${localSize} bytes)`);
        return resolve(true);
      }
      
      logMessage('INFO', `קובץ שונה: ${path.basename(localPath)} - מקומי: ${localSize}B, מרוחק: ${remoteSize}B`);
      return resolve(false);
    } catch (error) {
      logMessage('WARN', `שגיאה בבדיקת קובץ ${path.basename(localPath)}: ${error.message}`);
      return resolve(false);
    }
  });
}

function smartSync(serverImages, localImageDir) {
  return new Promise(async (resolve) => {
    try {
      // רשימת קבצים שצריך להוריד
      const filesToDownload = [];
      // רשימת קבצים קיימים שצריכים להישאר
      const filesToKeep = [];
      
      logMessage('INFO', `מתחיל סינכרון חכם עבור ${serverImages.length} תמונות`);
      
      // בדיקת כל תמונה מהשרת
      for (let i = 0; i < serverImages.length; i++) {
        const imageUrl = serverImages[i];
        let ext = path.extname(imageUrl).toLowerCase();
        const imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
        let destName;
        
        if (imageExts.includes(ext) && ext) {
          destName = `${i + 1}${ext}`;
        } else if (ext) {
          destName = `${i + 1}${ext}`;
        } else {
          destName = `${i + 1}.jpg`;
        }
        
        const localPath = path.join(localImageDir, destName);
        
        // בדיקה אם הקובץ קיים וזהה
        const isIdentical = await isFileIdentical(localPath, imageUrl);
        if (isIdentical) {
          filesToKeep.push(destName);
        } else {
          filesToDownload.push({ url: imageUrl, dest: localPath, name: destName });
        }
      }
      
      // מחיקת קבצים ישנים שלא רלוונטיים יותר
      let filesToDelete = [];
      if (fs.existsSync(localImageDir)) {
        const existingFiles = fs.readdirSync(localImageDir);
        const expectedFiles = serverImages.map((_, i) => {
          let ext = path.extname(serverImages[i]).toLowerCase();
          const imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
          if (imageExts.includes(ext) && ext) {
            return `${i + 1}${ext}`;
          } else if (ext) {
            return `${i + 1}${ext}`;
          } else {
            return `${i + 1}.jpg`;
          }
        });
        
        filesToDelete = existingFiles.filter(file => !expectedFiles.includes(file));
        for (const fileToDelete of filesToDelete) {
          const filePath = path.join(localImageDir, fileToDelete);
          try {
            fs.unlinkSync(filePath);
            logMessage('INFO', `מחק קובץ ישן: ${fileToDelete}`);
          } catch (error) {
            logMessage('WARN', `שגיאה במחיקת קובץ ישן ${fileToDelete}: ${error.message}`);
          }
        }
      }
      
      logMessage('INFO', `סינכרון חכם: ${filesToKeep.length} קבצים נשמרו, ${filesToDownload.length} יורדו, ${filesToDelete.length} נמחקו`);
      console.log(`🔄 סינכרון חכם: ${filesToKeep.length} נשמרו, ${filesToDownload.length} יורדו`);
      
      resolve({ filesToDownload, filesToKeep });
    } catch (error) {
      logMessage('ERROR', `שגיאה בסינכרון חכם: ${error.message}`);
      resolve({ filesToDownload: [], filesToKeep: [] });
    }
  });
}

function downloadImage(url, dest) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    https.get(url, response => {
      if (response.statusCode !== 200) {
        fs.unlink(dest, () => {});
        const error = new Error(`Failed to download image: ${url} – Status ${response.statusCode}`);
        logMessage('ERROR', `הורדת קובץ נכשלה: ${url} - סטטוס ${response.statusCode}`);
        return reject(error);
      }
      response.pipe(file);
      file.on("finish", () => {
        file.close();
        logMessage('INFO', `הורדת קובץ הושלמה: ${path.basename(dest)}`);
        resolve();
      });
    }).on("error", err => {
      fs.unlink(dest, () => {});
      logMessage('ERROR', `שגיאת רשת בהורדת קובץ: ${url} - ${err.message}`);
      reject(err);
    });
  });
}

// ========== פונקציה ליצירת daily-settings.json ==========
function createDailySettingsFile(userSettings, userFolder) {
  try {
    // נסה למצוא מייל לקוח מההגדרות
    let clientEmail = null;
    if (userSettings && userSettings.email) {
      clientEmail = userSettings.email;
    } else if (userSettings && userSettings.user_email) {
      clientEmail = userSettings.user_email;
    } else if (userSettings && userSettings.client_email) {
      clientEmail = userSettings.client_email;
    }

    const settingsData = {
      MAX_POSTS_PER_DAY: parseInt(userSettings?.max_posts_per_day) || 5,
      MAX_PUBLICATIONS_PER_DAY: parseInt(userSettings?.max_publications_per_day) || 15,
      DELAY_BETWEEN_POSTS_MINUTES: parseInt(userSettings?.delay_between_posts_minutes) || 10,
      ENABLE_SMART_DISTRIBUTION: userSettings?.enable_smart_distribution === "1" || userSettings?.enable_smart_distribution === 1,
      ENABLE_SABBATH_SHUTDOWN: userSettings?.enable_sabbath_shutdown === "1" || userSettings?.enable_sabbath_shutdown === 1,
      SABBATH_SHUTDOWN_HOURS_BEFORE: 1,
      CLIENT_EMAIL: clientEmail, // 📧 מייל הלקוח מהשרת
      description: `הגדרות יומיות למערכת הפרסום - משתמש: ${hostname}`,
      last_updated: new Date().toISOString(),
      synced_from_website: true,
      hostname: hostname
    };

    // יצירת הקובץ בתיקיית המשתמש
    const settingsPath = path.join(userFolder, "daily-settings.json");
    fs.writeFileSync(settingsPath, JSON.stringify(settingsData, null, 2), "utf-8");
    
    console.log(`✅ יצר קובץ הגדרות: ${settingsPath}`);
    console.log(`📊 הגדרות המשתמש:
      📝 פוסטים ביום: ${settingsData.MAX_POSTS_PER_DAY}
      📢 פרסומים ביום: ${settingsData.MAX_PUBLICATIONS_PER_DAY}
      ⏱️ השהייה: ${settingsData.DELAY_BETWEEN_POSTS_MINUTES} דקות
      🧠 חלוקה חכמה: ${settingsData.ENABLE_SMART_DISTRIBUTION ? 'מופעלת' : 'כבויה'}
      🕯️ כיבוי לשבת: ${settingsData.ENABLE_SABBATH_SHUTDOWN ? 'מופעל' : 'כבוי'}
      📧 מייל לקוח: ${settingsData.CLIENT_EMAIL || 'לא הוגדר'}`);
    
    return settingsPath;
  } catch (error) {
    console.error("❌ שגיאה ביצירת קובץ הגדרות:", error.message);
    return null;
  }
}

// ========== פונקציונלי בדיקה האם כבר נשלח מייל היום ==========
function getTodayString() {
  return new Date().toISOString().split('T')[0]; // פורמט: YYYY-MM-DD
}

function getEmailCacheFilePath(userFolder) {
  // שמור את ה-cache במיקום שלא נמחק בכל סינכרון
  const cacheDir = path.join("C:", "postify", "cache");
  if (!fs.existsSync(cacheDir)) {
    fs.mkdirSync(cacheDir, { recursive: true });
  }
  return path.join(cacheDir, `email-cache-${hostname}.json`);
}

function loadEmailCache(userFolder) {
  const cacheFile = getEmailCacheFilePath(userFolder);
  try {
    if (fs.existsSync(cacheFile)) {
      const data = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
      return data;
    }
  } catch (error) {
    logMessage('WARN', `שגיאה בקריאת קובץ cache: ${error.message}`);
  }
  return { lastEmailDate: null, lastFailedPosts: [] };
}

function saveEmailCache(userFolder, failedPosts) {
  const cacheFile = getEmailCacheFilePath(userFolder);
  const cacheData = {
    lastEmailDate: getTodayString(),
    lastFailedPosts: failedPosts.map(post => ({
      name: post.name,
      title: post.title,
      failedImages: post.failedImages,
      originalImageCount: post.originalImageCount
    })),
    timestamp: new Date().toISOString()
  };
  
  try {
    fs.writeFileSync(cacheFile, JSON.stringify(cacheData, null, 2), 'utf-8');
    logMessage('INFO', `נתוני cache נשמרו: ${cacheFile}`);
  } catch (error) {
    logMessage('ERROR', `שגיאה בשמירת cache: ${error.message}`);
  }
}

function areFailureListsEqual(list1, list2) {
  console.log(`🔍 משווה רשימות כשלונות: רשימה 1 (${list1.length} פריטים), רשימה 2 (${list2?.length || 0} פריטים)`);
  
  if (!list2 || list1.length !== list2.length) {
    console.log(`❌ אורכים שונים: ${list1.length} != ${list2?.length || 0}`);
    return false;
  }
  
  // מיין לפי name כדי להשוות בצורה עקבית
  const sorted1 = [...list1].sort((a, b) => a.name.localeCompare(b.name));
  const sorted2 = [...list2].sort((a, b) => a.name.localeCompare(b.name));
  
  for (let i = 0; i < sorted1.length; i++) {
    if (sorted1[i].name !== sorted2[i].name ||
        sorted1[i].failedImages !== sorted2[i].failedImages ||
        sorted1[i].originalImageCount !== sorted2[i].originalImageCount) {
      console.log(`❌ פריט ${i} שונה: ${sorted1[i].name} vs ${sorted2[i].name}`);
      return false;
    }
  }
  console.log(`✅ רשימות זהות`);
  return true;
}

// ========== פונקציה לשליחת מייל ללקוח על כשלונות ==========
async function sendClientFailureNotification(postsWithFailures, hostname, userSettings, userFolder, existingEmailCache) {
  if (postsWithFailures.length === 0) return;

  // בדיקה האם כבר נשלח מייל היום על אותן בעיות
  const emailCache = existingEmailCache || loadEmailCache(userFolder);
  const today = getTodayString();
  
  console.log(`🔍 בודק cache מיילים: היום ${today}, מייל אחרון: ${emailCache.lastEmailDate || 'אף פעם'}`);
  console.log(`🔍 מספר פוסטים בעיתיים כעת: ${postsWithFailures.length}, בקודם: ${emailCache.lastFailedPosts?.length || 0}`);
  
  if (emailCache.lastEmailDate === today && 
      areFailureListsEqual(postsWithFailures, emailCache.lastFailedPosts)) {
    logMessage('INFO', 'מייל זהה כבר נשלח היום - מדלג על שליחה נוספת');
    console.log('📧 מייל זהה כבר נשלח היום - מדלג על שליחה נוספת');
    return;
  }

  // נסה למצוא מייל לקוח מההגדרות
  let clientEmail = null;
  if (userSettings && userSettings.email) {
    clientEmail = userSettings.email;
  } else if (userSettings && userSettings.user_email) {
    clientEmail = userSettings.user_email;
  } else if (userSettings && userSettings.client_email) {
    clientEmail = userSettings.client_email;
  }

  if (!clientEmail) {
    logMessage('WARN', 'לא נמצא מייל לקוח בהגדרות - המייל יישלח למייל ברירת המחדל');
    console.log('⚠️ לא נמצא מייל לקוח - המייל יישלח למייל ברירת המחדל');
  } else {
    logMessage('INFO', `מייל לקוח נמצא: ${clientEmail}`);
    console.log(`📧 שולח מייל התראה ללקוח: ${clientEmail}`);
  }

  const subject = `⚠️ שגיאות בסינכרון פוסטים - ${hostname}`;
  
  // יצירת רשימה של הפוסטים הבעייתיים
  const postsList = postsWithFailures.map(post => {
    const mediaType = post.originalImageCount > 0 && post.originalImageCount <= 3 ? 'תמונות' : 'קבצי מדיה';
    return `• **${post.title}**: ${post.failedImages} ${mediaType} נכשלו מתוך ${post.originalImageCount}`;
  }).join('\n');
  
  const totalFailedFiles = postsWithFailures.reduce((sum, post) => sum + post.failedImages, 0);
  
  const textMessage = `
שלום,

זוהו שגיאות בסינכרון נתוני הפוסטים שלך מהאתר.

🔍 פרטי השגיאות:
${postsList}

📊 סיכום:
• ${postsWithFailures.length} פוסטים מושפעים
• ${totalFailedFiles} קבצי מדיה נכשלו בסך הכל

🔧 מה לעשות?
1. היכנס לעמוד הפוסטים באתר: https://postify.co.il/wp-admin/edit.php?post_type=post
2. מצא את הפוסטים הבעייתיים המפורטים למעלה
3. המלצה: מחק את כל התמונות/וידאו מהפוסטים הבעייתיים
4. העלה מחדש את התמונות/וידאו (ודא שהקבצים תקינים)
5. הרץ שוב סינכרון נתונים

⚠️ חשוב: הפוסטים עדיין מפורסמים באתר, רק חלק מהתמונות/וידאו לא הורדו למערכת הפרסום האוטומטית.

בברכה,
צוות Postify
  `.trim();

  const htmlMessage = `
<div dir="rtl" style="text-align:right;font-family:Arial,sans-serif;">
  <div style="background-color:#fff3e0;border:2px solid:#ff9800;border-radius:8px;padding:20px;">
    <h2 style="color:#e65100;margin-top:0;">⚠️ שגיאות בסינכרון פוסטים</h2>
    
    <div style="background-color:#e8f5e8;padding:10px;border-radius:5px;margin:10px 0;">
      <b>🖥️ שרת:</b> <span style="background-color:#4CAF50;color:white;padding:2px 8px;border-radius:3px;">${hostname}</span>
    </div>
    
    <div style="background-color:#ffffff;padding:15px;border-radius:5px;margin:15px 0;">
      <h3 style="color:#e65100;">🔍 פרטי השגיאות:</h3>
      <ul style="line-height:1.8;">
        ${postsWithFailures.map(post => 
          `<li><b>${post.title}</b>: ${post.failedImages} קבצי מדיה נכשלו מתוך ${post.originalImageCount}</li>`
        ).join('')}
      </ul>
    </div>
    
    <div style="background-color:#e3f2fd;padding:15px;border-radius:5px;margin:15px 0;">
      <b>📊 סיכום:</b><br>
      • ${postsWithFailures.length} פוסטים מושפעים<br>
      • ${totalFailedFiles} קבצי מדיה נכשלו בסך הכל
    </div>
    
    <div style="background-color:#ffcdd2;padding:15px;border-radius:5px;margin:15px 0;">
      <b>🔧 מה לעשות:</b><br>
      1. היכנס לעמוד הפוסטים באתר: <a href="https://postify.co.il/wp-admin/edit.php?post_type=post" target="_blank">לחץ כאן</a><br>
      2. מצא את הפוסטים הבעייתיים המפורטים למעלה<br>
      3. <b>המלצה:</b> מחק את כל התמונות/וידאו מהפוסטים הבעייתיים<br>
      4. העלה מחדש את התמונות/וידאו (ודא שהקבצים תקינים)<br>
      5. הרץ שוב סינכרון נתונים
    </div>
    
    <div style="background-color:#fff3e0;padding:10px;border-radius:5px;margin:10px 0;font-size:14px;">
      <b>💡 הערה:</b> הפוסטים עדיין מפורסמים באתר, רק חלק מהתמונות/וידאו לא הורדו למערכת הפרסום האוטומטית.
    </div>
    
    <div style="text-align:center;margin-top:20px;">
      <b>בברכה, צוות Postify</b>
    </div>
  </div>
</div>
  `.trim();

  try {
    // 🚧 זמנית: שליחת מיילים רק למנהל המערכת
    // שליחה למנהל המערכת בלבד
    await sendMail(subject, textMessage, htmlMessage);
    
    // שמירת המידע על המייל שנשלח ב-cache
    saveEmailCache(userFolder, postsWithFailures);
    
    if (clientEmail) {
      logMessage('INFO', `מייל התראה נשלח למנהל המערכת (שליחה ללקוח ${clientEmail} מושבתת זמנית) עבור ${postsWithFailures.length} פוסטים בעייתיים`);
      console.log(`📧 מייל התראה נשלח למנהל המערכת (שליחה ללקוח ${clientEmail} מושבתת זמנית) על ${postsWithFailures.length} פוסטים בעייתיים`);
    } else {
      logMessage('INFO', `מייל התראה נשלח למנהל המערכת עבור ${postsWithFailures.length} פוסטים בעייתיים`);
      console.log(`📧 מייל התראה נשלח למנהל המערכת על ${postsWithFailures.length} פוסטים בעייתיים`);
    }
  } catch (error) {
    logMessage('ERROR', `שגיאה בשליחת מייל ללקוח: ${error.message}`);
    console.error(`❌ שגיאה בשליחת מייל ללקוח: ${error.message}`);
  }
}

(async () => {
  try {
    logMessage('INFO', `התחלת סינכרון נתונים עבור ${hostname}`);
    console.log(`🌐 Fetching post data for ${hostname}...`);

    // ===== טעינת cache לפני התחלת הסינכרון =====
    let emailCache = { lastEmailDate: null, lastFailedPosts: [] };
    const cacheFile = getEmailCacheFilePath(userFolder);
    if (fs.existsSync(cacheFile)) {
      try {
        emailCache = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
        logMessage('INFO', `טעינת cache מיילים: ${cacheFile}`);
        console.log(`📋 טעינת cache מיילים: ${cacheFile}`);
      } catch (e) {
        logMessage('WARN', `שגיאה בטעינת cache: ${e.message}`);
      }
    } else {
      console.log(`📋 לא נמצא cache קיים - זו הריצה הראשונה היום`);
    }

    // יצירת התיקיות הבסיסיות (ללא מחיקת קבצים קיימים)
    fs.mkdirSync(userFolder, { recursive: true });
    fs.mkdirSync(path.join(userFolder, "posts"), { recursive: true });
    fs.mkdirSync(path.join(userFolder, "images"), { recursive: true });
    logMessage('INFO', `תיקיות נוצרו/וודאו: ${userFolder}`);
    console.log("📁 ודא שתיקיות קיימות (ללא מחיקה)...");

    // ========== שליפת נתונים משולבים (פוסטים + הגדרות) ==========
    logMessage('INFO', `שולף נתונים מ-API: ${apiUrl}`);
    const dataRes = await fetch(apiUrl);
    const data = await dataRes.json();
    
    let posts, userSettings;
    
    // בדיקה אם הקובץ מחזיר מבנה חדש (פוסטים + הגדרות) או מבנה ישן (רק פוסטים)
    if (data.posts && data.user_settings) {
        // מבנה חדש - יש הגדרות ופוסטים נפרדים
        posts = data.posts;
        userSettings = data.user_settings;
        logMessage('INFO', `נתונים התקבלו במבנה חדש: ${posts.length} פוסטים + הגדרות משתמש`);
        console.log(`📝 נמצאו ${posts.length} פוסטים למשתמש ${hostname}`);
        console.log(`⚙️ הגדרות משתמש נשלפו מ-API`);
    } else if (Array.isArray(data)) {
        // מבנה ישן - רק פוסטים
        posts = data;
        userSettings = null; // ברירת מחדל - ייצר הגדרות ברירת מחדל
        logMessage('INFO', `נתונים התקבלו במבנה ישן: ${posts.length} פוסטים בלבד`);
        console.log(`📝 נמצאו ${posts.length} פוסטים למשתמש ${hostname}`);
        console.log(`⚙️ הגדרות משתמש נשלפו מ-ברירת מחדל`);
    } else {
        logMessage('ERROR', 'תבנית לא מוכרת של נתונים מהשרת');
        throw new Error('תבנית לא מוכרת של נתונים מהשרת');
    }

    // ודא שהתיקייה קיימת לפני יצירת קובץ הגדרות
    logMessage('INFO', `תיקיית משתמש מוכנה: ${userFolder}`);
    
    // ========== יצירת קובץ הגדרות יומיות ==========
    console.log(`⚙️ יוצר קובץ daily-settings.json למשתמש...`);
    logMessage('INFO', 'יוצר קובץ הגדרות יומיות');
    const settingsPath = createDailySettingsFile(userSettings, userFolder);
    if (settingsPath) {
      console.log(`✅ קובץ הגדרות נוצר בהצלחה: ${settingsPath}`);
      logMessage('INFO', `קובץ הגדרות נוצר: ${settingsPath}`);
    } else {
      console.warn(`⚠️ בעיה ביצירת קובץ הגדרות`);
      logMessage('WARN', 'בעיה ביצירת קובץ הגדרות');
    }

    // ========== עיבוד פוסטים עם סינכרון חכם ========== 
    let totalPosts = posts.length;
    let totalImages = 0;
    let successfulImages = 0;
    let skippedImages = 0;
    let keptImages = 0; // תמונות שנשמרו מהריצה הקודמת
    let postsWithFailures = []; // פוסטים שיש להם כשלונות בתמונות
    
    // ========== ניקוי פוסטים שנמחקו מהאתר ==========
    const postsDir = path.join(userFolder, "posts");
    const imagesDir = path.join(userFolder, "images");
    
    // רשימת כל הפוסטים שאמורים להיות (מהשרת)
    const serverPostNames = new Set(posts.map(post => post.name));
    
    // בדיקה אילו פוסטים קיימים מקומית
    let deletedPosts = 0;
    let deletedImages = 0;
    
    if (fs.existsSync(postsDir)) {
        const localPostFiles = fs.readdirSync(postsDir);
        
        for (const postFile of localPostFiles) {
            if (!postFile.endsWith('.json')) continue;
            
            const postName = path.basename(postFile, '.json');
            
            // אם הפוסט לא קיים ברשימת השרת - מחק אותו
            if (!serverPostNames.has(postName)) {
                const postPath = path.join(postsDir, postFile);
                const postImageDir = path.join(imagesDir, postName);
                
                try {
                    // מחיקת קובץ הפוסט
                    fs.unlinkSync(postPath);
                    deletedPosts++;
                    logMessage('INFO', `מחק פוסט שנמחק מהאתר: ${postName}`);
                    console.log(`🗑️ מחק פוסט: ${postName}`);
                    
                    // מחיקת תיקיית התמונות של הפוסט
                    if (fs.existsSync(postImageDir)) {
                        const imageFiles = fs.readdirSync(postImageDir);
                        deletedImages += imageFiles.length;
                        
                        // מחיקת כל התמונות
                        for (const imageFile of imageFiles) {
                            fs.unlinkSync(path.join(postImageDir, imageFile));
                        }
                        
                        // מחיקת התיקיה עצמה
                        fs.rmdirSync(postImageDir);
                        logMessage('INFO', `מחק תיקיית תמונות: ${postName} (${imageFiles.length} קבצים)`);
                    }
                } catch (error) {
                    logMessage('ERROR', `שגיאה במחיקת פוסט ${postName}: ${error.message}`);
                    console.error(`❌ שגיאה במחיקת פוסט ${postName}: ${error.message}`);
                }
            }
        }
    }
    
    if (deletedPosts > 0) {
        console.log(`🧹 נמחקו ${deletedPosts} פוסטים ישנים ו-${deletedImages} תמונות`);
        logMessage('INFO', `ניקוי הושלם: ${deletedPosts} פוסטים ו-${deletedImages} תמונות נמחקו`);
    } else {
        console.log(`✅ כל הפוסטים המקומיים עדיין רלוונטיים`);
        logMessage('INFO', 'לא נמצאו פוסטים ישנים למחיקה');
    }
    
    logMessage('INFO', `מתחיל עיבוד ${totalPosts} פוסטים`);
    
    
    for (const post of posts) {
      let postFailedImages = 0; // מונה תמונות שנכשלו לפוסט הנוכחי
      let postOriginalImageCount = post.images.length; // מספר התמונות המקורי
      
      try {
        logMessage('INFO', `מעבד פוסט: ${post.title || post.post_title || post.name} (${post.images.length} תמונות)`);
        
        const postPath = path.join(userFolder, "posts", `${post.name}.json`);
        const postImageDir = path.join(userFolder, "images", post.name);
        fs.mkdirSync(postImageDir, { recursive: true });

        totalImages += post.images.length;

        // תיקון URL-ים של תמונות
        const serverImages = post.images.map(imageUrl => {
          if (!imageUrl.startsWith("http")) {
            return "https://postify.co.il/wp-content/postify-api/" + imageUrl.replace(/^\+|^\/+/, "");
          }
          return imageUrl;
        });

        // סינכרון חכם - השוואה לתמונות קיימות
        console.log(`🔍 מבצע סינכרון חכם עבור ${post.name}...`);
        const { filesToDownload, filesToKeep } = await smartSync(serverImages, postImageDir);
        
        keptImages += filesToKeep.length;

        // הורדת תמונות חדשות/שונות בלבד
        for (const fileInfo of filesToDownload) {
          try {
            console.log(`⬇️ Downloading: ${fileInfo.url}`);
            await downloadImage(fileInfo.url, fileInfo.dest);
            successfulImages++;
          } catch (imageError) {
            logMessage('WARN', `דילוג על תמונה בפוסט ${post.title || post.post_title || post.name}: ${imageError.message}`);
            skippedImages++;
            postFailedImages++;
            continue;
          }
        }

        // עדכון נתיבי התמונות בפוסט
        for (let i = 0; i < serverImages.length; i++) {
          let ext = path.extname(serverImages[i]).toLowerCase();
          const imageExts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
          let destName;
          
          if (imageExts.includes(ext) && ext) {
            destName = `${i + 1}${ext}`;
          } else if (ext) {
            destName = `${i + 1}${ext}`;
          } else {
            destName = `${i + 1}.jpg`;
          }
          
          const imageDest = path.join(postImageDir, destName);
          post.images[i] = imageDest; // עדכון הנתיב המקומי
        }

        // ספירת תמונות שהושלמו בהצלחה
        successfulImages += filesToKeep.length;

        // אם יש כשלונות בפוסט זה, הוסף לרשימת הפוסטים עם בעיות
        if (postFailedImages > 0) {
          postsWithFailures.push({
            name: post.name,
            title: post.title || post.post_title || post.name,
            failedImages: postFailedImages,
            originalImageCount: postOriginalImageCount,
            successfulImages: postOriginalImageCount - postFailedImages
          });
          logMessage('WARN', `פוסט ${post.title || post.post_title || post.name}: ${postFailedImages} תמונות נכשלו מתוך ${postOriginalImageCount}`);
        }

        // שמור את הפוסט (גם אם חלק מהתמונות נכשלו)
        fs.writeFileSync(postPath, JSON.stringify(post, null, 2), "utf-8");
        logMessage('INFO', `פוסט ${post.title || post.post_title || post.name} נשמר בהצלחה`);
        
      } catch (postError) {
        logMessage('ERROR', `שגיאה בעיבוד פוסט ${post.title || post.post_title || post.name}: ${postError.message}`);
        continue;
      }
    }

    // סיכום התהליך
    logMessage('INFO', `סינכרון הושלם בהצלחה`);
    logMessage('INFO', `פוסטים: ${totalPosts} סונכרנו`);
    if (deletedPosts > 0) {
      logMessage('INFO', `פוסטים ישנים: ${deletedPosts} נמחקו (${deletedImages} תמונות)`);
    }
    logMessage('INFO', `תמונות: ${successfulImages}/${totalImages} הורדו/נשמרו בהצלחה (${keptImages} נשמרו מהריצה הקודמת)`);
    if (skippedImages > 0) {
      logMessage('WARN', `${skippedImages} תמונות דולגו בגלל שגיאות`);
    }

    // שליחת מייל ללקוח אם יש כשלונות
    if (postsWithFailures.length > 0) {
      console.log(`📧 נמצאו כשלונות ב-${postsWithFailures.length} פוסטים - בודק אם צריך לשלוח מייל התראה...`);
      await sendClientFailureNotification(postsWithFailures, hostname, userSettings, userFolder, emailCache);
    } else {
      console.log(`✅ כל הפוסטים סונכרנו בהצלחה מלאה - אין צורך במייל התראה`);
    }

    console.log(`\n🎉 Smart sync complete for ${hostname}!`);
    console.log(`📁 נתונים נשמרו ב: ${userFolder}`);
    console.log(`📊 ${totalPosts} פוסטים סונכרנו`);
    if (deletedPosts > 0) {
      console.log(`🗑️ ${deletedPosts} פוסטים ישנים נמחקו (${deletedImages} תמונות)`);
    }
    console.log(`🖼️ תמונות: ${successfulImages}/${totalImages} מוכנות (${keptImages} נשמרו, ${successfulImages - keptImages} הורדו חדש, ${skippedImages} דולגו)`);
    if (postsWithFailures.length > 0) {
      console.log(`⚠️ ${postsWithFailures.length} פוסטים עם בעיות - נשלח מייל ללקוח`);
    }
    console.log(`⚙️ הגדרות יומיות מוכנות לשימוש`);
    console.log(`🚀 הסינכרון החכם חוסך זמן ולא מוריד מחדש קבצים זהים!`);
    
    // שמירת לוג לקובץ
    saveLogToFile();
    
  } catch (err) {
    logMessage('ERROR', `כשלון כללי בסינכרון: ${err.message}`);
    console.error("❌ Sync failed:", err.message);
    saveLogToFile(); // שמור לוג גם במקרה של שגיאה כללית
  }
})();