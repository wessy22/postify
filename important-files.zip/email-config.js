module.exports = {
  user: "support@postify.co.il",         // כתובת המייל השולחת
  pass: "mwib fxwi ncwc vwzd",         // סיסמת אפליקציה (לא רגילה!)
  to: "postify.user@gmail.com",               // כתובת היעד שתקבל התראות
  errorTo: "postify.user@gmail.com"        // מייל לקבלת שגיאות מערכת
};
