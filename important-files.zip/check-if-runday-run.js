const fs = require('fs');
const nodemailer = require('nodemailer');
const { execSync } = require('child_process');
const path = require('path');

// קריאת שם השרת
const serverName = fs.existsSync('instance-name.txt')
  ? fs.readFileSync('instance-name.txt', 'utf-8').trim()
  : 'Unknown';

// קריאת הגדרות מייל מתוך config.json
const config = JSON.parse(fs.readFileSync('config.json', 'utf-8'));
const email = config.email;

// בדיקת תהליך run-daily.bat (בודק אם cmd.exe מריץ אותו)
let running = false;
try {
  const out = execSync('tasklist /FI "IMAGENAME eq cmd.exe" /V /FO LIST').toString();
  running = out.toLowerCase().includes('run-daily.bat');
} catch (e) {
  running = false;
}

if (!running) {
  const subject = 'שגיאה חמורה 🚨';
  const body =
    `התהליך run-daily.bat **לא רץ** כרגע על שרת "${serverName}".\n\n` +
    `נבדק בתאריך: ${new Date().toLocaleString('he-IL')}\n` +
    `אנא בדוק את השרת בדחיפות!`;

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: email.user,
      pass: email.pass,
    }
  });

  transporter.sendMail(
    {
      from: `"Postify" <${email.user}>`,
      to: email.to,
      subject,
      text: body,
    },
    (err, info) => {
      if (err) {
        console.error('❌ שגיאה בשליחת מייל:', err.message);
      } else {
        console.log('✅ נשלח מייל:', info.response);
      }
    }
  );
} else {
  console.log('✅ run-daily.bat פועל כסדרו');
}
