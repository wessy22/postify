module.exports = {
  host: "s-il-797-fsr.upress.io",
  user: "postr3xd_up1",
  password: "hvr%4ho2iaQN3Hfd_6",
  database: "postr3xd_up1",
  charset: "utf8mb4"
};
