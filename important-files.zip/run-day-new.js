const fs = require('fs');
const { sendErrorMail, sendMail } = require("./mailer");

// פונקציה לבדיקת פוסטים מתאימים להיום
function isTodayScheduled(post, today = new Date()) {
  if (post.status === "paused" || post.status === "finished") return false;

  const sched = post.schedule || {};
  if (sched.type === "one-time") {
    if (!sched.oneTime?.date) return false;
    const todayStr = today.toISOString().slice(0,10);
    return todayStr === sched.oneTime.date;
  }

  if (sched.type === "recurring") {
    const freq = sched.recurring.frequency;
    if (sched.recurring.startDate && today < new Date(sched.recurring.startDate)) return false;
    if (sched.recurring.endDate && today > new Date(sched.recurring.endDate)) return false;
    if (typeof sched.recurring.maxRepeats === "number" && post.publishCount >= sched.recurring.maxRepeats) return false;
    if (freq === "daily") return true;
    if (freq === "weekly") {
      return (sched.recurring.daysOfWeek || []).includes(today.getDay());
    }
    if (freq === "monthly") {
      return (sched.recurring.daysOfMonth || []).includes(today.getDate());
    }
  }
  // אם אין הגדרה בכלל, פרסם כל יום (לשמור תאימות לאחור)
  return !sched.type;
}

// פונקציה להסבר קוד יציאה
function explainExitCode(code) {
  if (code === 0) return "בוצע בהצלחה.";
  const hex = "0x" + code.toString(16).toUpperCase();
  const map = {
    1: "בעיה כללית – ייתכן שהסקריפט סיים עם שגיאה.",
    3221225477: "שגיאת גישה לזיכרון (Access Violation) – ייתכן שקרס תהליך פנימי.",
    3221225781: "חסרה ספריה או מודול. ודא שכל הקבצים קיימים.",
    3221226505: "שגיאה קשה (Buffer Overrun / Stack Error) – כנראה קריסת Node או שגיאת סינטקס.",
  };
  const reason = map[code] || `שגיאה כללית או לא מזוהה (קוד: ${code}, hex: ${hex})`;
  return reason + ` (קוד: ${code}, hex: ${hex})`;
}

(async () => {
  try {
    const path = require("path");
    const { spawn, exec } = require("child_process");
    const logToSheet = require("./log-to-sheets");
    const config = require("./config.json");

    let instanceName;
    let instanceTries = 0;
    while (instanceTries < 2) {
      try {
        instanceName = fs.readFileSync("C:\\postify\\posts\\instance-name.txt", "utf-8").trim();
        break;
      } catch (e) {
        instanceTries++;
        await sendErrorMail("❌ שגיאה בקריאת instance-name.txt", e.message);
        if (instanceTries < 2) {
          await new Promise(r => setTimeout(r, 10000));
        } else {
          return;
        }
      }
    }
    const POSTS_FOLDER = `C:\\postify\\user data\\${instanceName}\\posts`;
    const LOG_FILE = path.join(__dirname, config.logFile);
    const STATE_POST_FILE = path.join(__dirname, "state-post.json");
    const CURRENT_GROUP_NAME_FILE = path.join(__dirname, config.currentGroupFile);

    const logStream = fs.createWriteStream(LOG_FILE, { flags: "a" });
    const log = (text) => {
      const timestamp = new Date().toLocaleString("sv-SE", { timeZone: "Asia/Jerusalem" }).replace(" ", "T");
      const line = `[${timestamp}] ${text}`;
      console.log(text);
      logStream.write(line + "\n");
    };

    const day = new Date().getDay();
    const todayStr = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

    // חגי ישראל + ימי זיכרון 2024-2035
    const jewishHolidaysAndMemorials = [
      // 2024
      "2024-04-22","2024-04-23","2024-04-28","2024-05-06","2024-05-13","2024-06-12","2024-10-02","2024-10-03","2024-10-11","2024-10-16","2024-10-23",
      // 2025
      "2025-04-13","2025-04-14","2025-04-19","2025-04-24","2025-05-01","2025-06-02","2025-10-03","2025-10-04","2025-10-12","2025-10-17","2025-10-24",
      // 2026
      "2026-04-02","2026-04-03","2026-04-08","2026-04-14","2026-04-21","2026-05-22","2026-09-22","2026-09-23","2026-10-01","2026-10-06","2026-10-13",
      // 2027
      "2027-03-22","2027-03-23","2027-03-28","2027-04-30","2027-05-06","2027-05-11","2027-09-11","2027-09-12","2027-09-20","2027-09-25","2027-10-02",
      // 2028
      "2028-04-10","2028-04-11","2028-04-16","2028-04-19","2028-04-26","2028-06-01","2028-09-30","2028-10-01","2028-10-09","2028-10-14","2028-10-21",
      // 2029
      "2029-03-30","2029-03-31","2029-04-05","2029-04-12","2029-04-18","2029-05-21","2029-09-19","2029-09-20","2029-09-28","2029-10-03","2029-10-10",
      // 2030
      "2030-04-18","2030-04-19","2030-04-24","2030-05-02","2030-05-08","2030-06-10","2030-10-08","2030-10-09","2030-10-17","2030-10-22","2030-10-29",
      // 2031
      "2031-04-07","2031-04-08","2031-04-13","2031-04-23","2031-04-29","2031-05-30","2031-09-27","2031-09-28","2031-10-06","2031-10-11","2031-10-18",
      // 2032
      "2032-03-26","2032-03-27","2032-04-01","2032-04-19","2032-04-25","2032-05-18","2032-09-15","2032-09-16","2032-09-24","2032-09-29","2032-10-06",
      // 2033
      "2033-04-14","2033-04-15","2033-04-20","2033-04-28","2033-05-04","2033-06-07","2033-10-04","2033-10-05","2033-10-13","2033-10-18","2033-10-25",
      // 2034
      "2034-04-04","2034-04-05","2034-04-10","2034-04-17","2034-04-23","2034-05-28","2034-09-24","2034-09-25","2034-10-03","2034-10-08","2034-10-15",
      // 2035
      "2035-03-24","2035-03-25","2035-03-30","2035-04-09","2035-04-15","2035-05-17","2035-09-13","2035-09-14","2035-09-22","2035-09-27","2035-10-04"
    ];

    // בדיקה אם היום שבת, חג או יום זיכרון
    if (day === 6 || jewishHolidaysAndMemorials.includes(todayStr)) {
      log("🛑 שבת, חג או יום זיכרון — אין פרסום היום.");
      process.exit(0);
    }

    async function countdown(seconds) {
      for (let i = seconds; i > 0; i--) {
        process.stdout.write(`⏳ ${i}s remaining...\r`);
        await new Promise(r => setTimeout(r, 1000));
      }
      console.log();
    }

    // ============ לולאת פרסום חדשה עם resume, heartbeat וללא דוח יומי ============
    async function runPostsForToday(postsToday) {
      if (postsToday.length === 0) {
        log("✅ אין פוסטים מתאימים להיום.");
        await logToSheet("Day finished", "Success", "", "אין פוסטים מתאימים להיום");
        return;
      }

      let startPost = 0;
      let startGroup = 0;
      if (fs.existsSync(STATE_POST_FILE)) {
        try {
          const state = JSON.parse(fs.readFileSync(STATE_POST_FILE, "utf-8"));
          if (state.date === todayStr) {
            startPost = state.postIndex || 0;
            startGroup = state.groupIndex || 0;
            log(`🔁 ממשיך מהריצה הקודמת: פוסט ${startPost + 1}/${postsToday.length}, קבוצה ${startGroup + 1}`);
          }
        } catch (e) {
          log("⚠️ לא ניתן לקרוא את קובץ ה־state-post. מתחיל מההתחלה.");
        }
      }

      for (let pi = startPost; pi < postsToday.length; pi++) {
        const post = postsToday[pi];
        for (let gi = (pi === startPost ? startGroup : 0); gi < post.groups.length; gi++) {
          const groupUrl = post.groups[gi];

          // לפני ניסיון פרסום
          updateHeartbeat({
            group: groupUrl,
            postFile: post.filename,
            status: 'before',
            index: gi
          });

          let retryCount = 0;
          let success = false;

          while (retryCount < 2 && !success) {
            await new Promise((resolve) => {
              // --- Heartbeat (ניטור) ---
              fs.writeFileSync('C:/postify/alive.txt', JSON.stringify({
                datetime: new Date().toISOString(),
                postIndex: pi,
                groupIndex: gi,
                postFile: post.filename,
                groupUrl
              }));

              const child = spawn("node", ["post.js", groupUrl, post.filename], { stdio: "inherit" });

              // --- Timeout ---
              const TIMEOUT = 13 * 60 * 1000;
              let timeoutId = setTimeout(() => {
                log(`⏰ Timeout! post.js לקח יותר מ־13 דקות. סוגר תהליך וממשיך...`);
                child.kill("SIGKILL");
                sendErrorMail("⏰ Timeout - קבוצה נתקעה", `הקבוצה ${groupUrl} נתקעה ליותר מ־13 דקות ונעצרה אוטומטית.`);
              }, TIMEOUT);

              // --- עדכון state ---
              fs.writeFileSync(STATE_POST_FILE, JSON.stringify({
                date: todayStr, postIndex: pi, groupIndex: gi
              }), "utf-8");

              child.on("exit", async (code) => {
                clearTimeout(timeoutId);
                const now = new Date();
                const groupTime = now.toLocaleTimeString("he-IL", { hour: '2-digit', minute: '2-digit' });
                if (code === 0) {
                  success = true;
                  log(`✅ פורסם בהצלחה בקבוצה: ${groupUrl}`);
                  await logToSheet("Publishing finished", "Success", groupUrl, groupTime);
                } else {
                  const reason = explainExitCode(code);
                  log(`❌ שגיאה בפרסום לקבוצה ${groupUrl}: ${reason}`);
                  await sendErrorMail("❌ שגיאה בפרסום לקבוצה", `קובץ: ${post.filename}\nקבוצה: ${groupUrl}\n${reason}`);
                  await logToSheet("Publishing finished", "Failed", groupUrl, groupTime);
                  if (retryCount < 1) {
                    log("🔁 מנסה שוב לפרסם לקבוצה...");
                  }
                }

                // --- השהייה רנדומלית מה-config ---
                const delaySec = config.minDelaySec + Math.floor(Math.random() * (config.maxDelaySec - config.minDelaySec + 1));
                const minutes = Math.floor(delaySec / 60);
                const seconds = delaySec % 60;
                log(`⏱ ממתין ${minutes} דקות ו־${seconds} שניות לפני הקבוצה הבאה...`);
                await countdown(delaySec);

                resolve();
              });
            });
            retryCount++;
          }
        }
        // עדכון אחרי שכל הקבוצות
        post.lastPublished = new Date().toISOString().slice(0,10);
        post.publishCount = (post.publishCount || 0) + 1;
        let finished = false;
        if (post.schedule.type === "one-time") finished = true;
        if (post.schedule.type === "recurring" && typeof post.schedule.recurring.maxRepeats === "number") {
          finished = post.publishCount >= post.schedule.recurring.maxRepeats;
        }
        if (finished) post.status = "finished";
        fs.writeFileSync(path.join(POSTS_FOLDER, post.filename), JSON.stringify(post, null, 2), "utf-8");
      }
      log("✅ כל הפוסטים להיום פורסמו.");

      // מחיקת סטייט כי סיימנו בהצלחה
      if (fs.existsSync(STATE_POST_FILE)) fs.unlinkSync(STATE_POST_FILE);

      // סיום יום: log-cost, מייל סגירה, כיבוי
      setTimeout(() => {
        log("📝 מריץ log-cost.bat לפני כיבוי...");
        exec("start /b C:\\postify\\posts\\log-cost.bat", (error) => {
          if (error) {
            log("❌ שגיאה בהרצת log-cost.bat: " + error.message);
          } else {
            log("✅ log-cost.bat הורץ בהצלחה.");
          }
          setTimeout(() => {
            log("📧 שולח מייל סגירה...");
            exec("node C:\\postify\\posts\\send-shutdown-mail.js", (mailError) => {
              if (mailError) {
                log("❌ שגיאה בשליחת מייל סגירה: " + mailError.message);
              } else {
                log("✅ מייל סגירה נשלח בהצלחה.");
              }
              setTimeout(() => {
                log("💤 כיבוי השרת עכשיו...");
                exec("shutdown /s /f /t 0", (shutdownError) => {
                  if (shutdownError) {
                    log("❌ שגיאה בכיבוי: " + shutdownError.message);
                  }
                });
              }, 30000);
            });
          }, 60000);
        });
      }, 4 * 60000);
    }

    // --- טעינת הפוסטים וסינון לפי היום ---
    const postFiles = fs.readdirSync(POSTS_FOLDER)
      .filter(f => /^post\d+\.json$/.test(f));
    const postsToday = [];
    const today = new Date();
    for (const fname of postFiles) {
      const post = JSON.parse(fs.readFileSync(path.join(POSTS_FOLDER, fname), "utf-8"));
      if (isTodayScheduled(post, today)) {
        postsToday.push({ ...post, filename: fname });
      }
    }

    // --- הפעלת הלולאה החדשה ---
    await runPostsForToday(postsToday);

  } catch (err) {
    console.error("❌ שגיאה באוטומציה:", err);
    await sendErrorMail("❌ שגיאה באוטומציה", [
      `🛑 התרחשה שגיאה בסקריפט: ${__filename}`,
      "",
      `❗ שגיאה: ${err.message}`,
      "",
      err.stack,
    ].join("\n"));
    return;
  }
})();
