const puppeteer = require("puppeteer-core");
const os = require("os");
const config = require("./config.json");
const fs = require("fs");
const path = require("path");

// פונקציה ליצירת לוג מפורט
function writeDetailedLog(message, type = 'INFO') {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [${type}] ${message}\n`;
  
  try {
    fs.appendFileSync('groups-post-status-scan.log', logMessage);
  } catch (e) {
    console.error('שגיאה בכתיבת לוג:', e.message);
  }
  
  // גם לקונסול
  console.log(`[${type}] ${message}`);
}

// פונקציה לשליפת הקבוצות שפורסמו אליהן היום
function getTodayPublishedGroups(targetDate = null) {
  const searchDate = targetDate || new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  writeDetailedLog(`מחפש קבוצות שפורסמו בתאריך: ${searchDate}...`, 'INFO');
  
  const todayGroups = [];
  
  try {
    // בדיקה אם קיים קובץ Google Sheets log מהיום
    const instanceName = fs.readFileSync(path.join(__dirname, 'instance-name.txt'), 'utf-8').trim();
    
    // חיפוש בקבצי לוג שונים
    const logFiles = [
      'groups-post-status-scan.log',
      'log.txt',
      'postify-logs.txt'
    ];
    
    // גם נחפש בקבצי JSON של פוסטים
    const userDataPath = `C:/postify/user data/${instanceName}/posts`;
    if (fs.existsSync(userDataPath)) {
      const postFiles = fs.readdirSync(userDataPath).filter(f => f.endsWith('.json'));
      
      postFiles.forEach(postFile => {
        try {
          const postPath = path.join(userDataPath, postFile);
          const postData = JSON.parse(fs.readFileSync(postPath, 'utf8'));
          
          // בדיקה אם הפוסט פורסם בתאריך המבוקש
          if (postData.lastPublished === searchDate && postData.groups) {
            writeDetailedLog(`נמצא פוסט שפורסם בתאריך ${searchDate}: ${postFile}`, 'INFO');
            
            // הוספת כל הקבוצות של הפוסט
            postData.groups.forEach(group => {
              if (group.url && group.name) {
                todayGroups.push({
                  name: group.name,
                  url: group.url,
                  postFile: postFile,
                  postTitle: postData.title || postFile
                });
              }
            });
          }
        } catch (e) {
          writeDetailedLog(`שגיאה בקריאת פוסט ${postFile}: ${e.message}`, 'WARNING');
        }
      });
    }
    
    // אם לא נמצאו קבוצות בפוסטים, ננסה למצוא בדרכים אחרות
    if (todayGroups.length === 0) {
      writeDetailedLog('לא נמצאו קבוצות בקבצי הפוסטים, מחפש בדרכים אחרות...', 'WARNING');
      
      // בדיקה אם יש קובץ last-published-posts.json
      const lastPostsPath = path.join(__dirname, 'last-published-posts.json');
      if (fs.existsSync(lastPostsPath)) {
        try {
          const lastPostsData = JSON.parse(fs.readFileSync(lastPostsPath, 'utf8'));
          writeDetailedLog(`נמצא קובץ פוסטים אחרונים: ${lastPostsData.allPosts?.length || 0} פוסטים`, 'INFO');
          
          // עבור כל פוסט שפורסם, חפש את הקבוצות שלו
          if (lastPostsData.allPosts) {
            lastPostsData.allPosts.forEach(postFilename => {
              const postPath = path.join(userDataPath, postFilename);
              if (fs.existsSync(postPath)) {
                try {
                  const postData = JSON.parse(fs.readFileSync(postPath, 'utf8'));
                  if (postData.groups) {
                    postData.groups.forEach(group => {
                      if (group.url && group.name) {
                        todayGroups.push({
                          name: group.name,
                          url: group.url,
                          postFile: postFilename,
                          postTitle: postData.title || postFilename
                        });
                      }
                    });
                  }
                } catch (e) {
                  writeDetailedLog(`שגיאה בקריאת פוסט מרשימת פוסטים אחרונים ${postFilename}: ${e.message}`, 'WARNING');
                }
              }
            });
          }
        } catch (e) {
          writeDetailedLog(`שגיאה בקריאת קובץ פוסטים אחרונים: ${e.message}`, 'WARNING');
        }
      }
    }
    
    // הסרת כפילויות
    const uniqueGroups = [];
    const seenUrls = new Set();
    
    todayGroups.forEach(group => {
      if (!seenUrls.has(group.url)) {
        seenUrls.add(group.url);
        uniqueGroups.push(group);
      }
    });
    
    writeDetailedLog(`נמצאו ${uniqueGroups.length} קבוצות ייחודיות שפורסמו בתאריך ${searchDate}`, 'SUCCESS');
    return uniqueGroups;
    
  } catch (error) {
    writeDetailedLog(`שגיאה בחיפוש קבוצות: ${error.message}`, 'ERROR');
    return [];
  }
}

// פונקציה לבדיקת סטטוס פרסום בקבוצה
async function checkPostStatusInGroup(page, groupUrl, groupName) {
  try {
    writeDetailedLog(`בודק סטטוס פרסום בקבוצה: ${groupName}`, 'INFO');
    
    // בניית URL עם my_posted_content
    const statusUrl = groupUrl.endsWith('/') 
      ? groupUrl + 'my_posted_content' 
      : groupUrl + '/my_posted_content';
    
    writeDetailedLog(`נכנס לכתובת: ${statusUrl}`, 'DEBUG');
    
    // מעבר לעמוד הקבוצה
    await page.goto(statusUrl, {
      waitUntil: "networkidle2", 
      timeout: 30000
    });
    
    // המתנה לטעינת העמוד
    await new Promise(res => setTimeout(res, 3000));
    
    // גלילה קצרה כדי לטעון יותר תוכן
    await page.evaluate(() => {
      window.scrollTo(0, window.innerHeight);
    });
    await new Promise(res => setTimeout(res, 2000));
    
    // חיפוש אחר פוסטים מהיום
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    
    const statuses = await page.evaluate((todayDate, yesterdayDate) => {
      const results = [];
      
      // מחפש סלקטורים נוספים לפוסטים
      const postSelectors = [
        '[data-pagelet*="FeedUnit"]',
        '[role="article"]',
        '.userContentWrapper',
        '[data-testid="story-subtitle"]',
        '.story_body_container',
        '.fbUserContent',
        '.fbPhotoSnowbox'
      ];
      
      let posts = [];
      postSelectors.forEach(selector => {
        const foundPosts = document.querySelectorAll(selector);
        foundPosts.forEach(post => {
          if (!posts.includes(post)) {
            posts.push(post);
          }
        });
      });
      
      // אם לא נמצאו פוסטים, חפש באזורים כלליים יותר
      if (posts.length === 0) {
        posts = Array.from(document.querySelectorAll('div')).filter(div => {
          const text = div.textContent || '';
          return text.includes('פורסם') || text.includes('posted') || 
                 text.includes('בהמתנה') || text.includes('pending') ||
                 text.includes('נדחה') || text.includes('declined');
        });
      }
      
      posts.forEach((post, index) => {
        try {
          const postText = post.textContent || '';
          
          // חיפוש תאריך בפוסט - גישה מרחיבה יותר
          let postDate = null;
          
          // חיפוש אלמנטי זמן
          const timeElements = post.querySelectorAll(
            'a[role="link"] time, .timestampContent, [data-testid="story-subtitle"] a, .timestamp, ' +
            '[data-utime], [data-testid="story-subtitle"], .story_body_container time, ' +
            'abbr[data-utime], span[data-utime]'
          );
          
          timeElements.forEach(timeEl => {
            const dateStr = timeEl.getAttribute('datetime') || 
                           timeEl.getAttribute('title') || 
                           timeEl.getAttribute('data-utime') ||
                           timeEl.textContent;
            
            if (dateStr) {
              // בדיקת תאריך היום או אתמול
              if (dateStr.includes(todayDate) || postText.includes(todayDate)) {
                postDate = todayDate;
              } else if (dateStr.includes(yesterdayDate) || postText.includes(yesterdayDate)) {
                postDate = yesterdayDate;
              } else if (dateStr.includes('היום') || dateStr.includes('today')) {
                postDate = todayDate;
              } else if (dateStr.includes('אתמול') || dateStr.includes('yesterday')) {
                postDate = yesterdayDate;
              }
            }
          });
          
          // אם לא נמצא תאריך באלמנטים, חפש בטקסט
          if (!postDate) {
            const timePatterns = [
              /(\d{1,2}:\d{2})/,  // זמן בפורמט שעה:דקה
              /(לפני \d+ שעות?)/, // "לפני X שעות"
              /(לפני כמה שעות)/, // "לפני כמה שעות"
              /(הרגע|זה עתה)/, // "הרגע", "זה עתה"
            ];
            
            for (const pattern of timePatterns) {
              if (pattern.test(postText)) {
                postDate = todayDate; // אם יש זמן מהיום, זה כנראה מהיום
                break;
              }
            }
          }
          
          // בדיקה אם זה פוסט מהיום או אתמול
          if (postDate === todayDate || postDate === yesterdayDate) {
            // זיהוי סטטוס מתקדם יותר
            let status = 'לא ידוע';
            const lowerText = postText.toLowerCase();
            
            // בדיקות סטטוס מפורטות יותר
            if (lowerText.includes('הפוסט שלך בהמתנה') || 
                lowerText.includes('pending review') ||
                lowerText.includes('ממתין לאישור') ||
                lowerText.includes('awaiting approval') ||
                post.querySelector('[data-testid*="pending"]')) {
              status = 'בהמתנה לאישור';
            } else if (lowerText.includes('הפוסט שלך נדחה') || 
                      lowerText.includes('declined') || 
                      lowerText.includes('rejected') ||
                      lowerText.includes('לא אושר') ||
                      post.querySelector('[data-testid*="declined"]')) {
              status = 'נדחה';
            } else if (lowerText.includes('הפוסט הוסר') || 
                      lowerText.includes('removed') ||
                      lowerText.includes('נמחק') ||
                      post.querySelector('[data-testid*="removed"]')) {
              status = 'הוסר';
            } else if (post.querySelector('[data-testid="post_timestamp"]') || 
                      post.querySelector('.timestamp') ||
                      post.querySelector('[data-utime]') ||
                      lowerText.includes('פורסם') ||
                      lowerText.includes('published')) {
              status = 'פורסם בהצלחה';
            } else if (lowerText.includes('שגיאה') || lowerText.includes('error')) {
              status = 'שגיאה בפרסום';
            }
            
            // שליפת תוכן הפוסט מכמה מקורות אפשריים
            let content = 'לא נמצא תוכן';
            const contentSelectors = [
              '[data-testid="post_message"]', 
              '.userContent', 
              '.text_exposed_root',
              '.story_body_container',
              '.fbUserContent',
              '.text_exposed_show'
            ];
            
            for (const selector of contentSelectors) {
              const contentEl = post.querySelector(selector);
              if (contentEl && contentEl.textContent.trim()) {
                content = contentEl.textContent.trim().substring(0, 150) + '...';
                break;
              }
            }
            
            // אם עדיין לא נמצא תוכן, קח מהטקסט הכללי
            if (content === 'לא נמצא תוכן' && postText.length > 50) {
              // נסה למצוא תוכן שנראה כמו פוסט (לא כמו UI elements)
              const lines = postText.split('\n').filter(line => 
                line.length > 10 && 
                !line.includes('לייק') && 
                !line.includes('תגובה') && 
                !line.includes('שתף')
              );
              if (lines.length > 0) {
                content = lines[0].substring(0, 150) + '...';
              }
            }
            
            results.push({
              status: status,
              content: content,
              date: postDate,
              index: index,
              rawText: postText.substring(0, 200) // לדיבוג
            });
          }
        } catch (e) {
          console.log('שגיאה בעיבוד פוסט:', e.message);
        }
      });
      
      return results;
    }, today, yesterday);
    
    writeDetailedLog(`נמצאו ${statuses.length} פוסטים רלוונטיים בקבוצה ${groupName}`, 'INFO');
    
    return {
      groupName: groupName,
      groupUrl: groupUrl,
      statusUrl: statusUrl,
      posts: statuses,
      scanTime: new Date().toISOString(),
      success: true
    };
    
  } catch (error) {
    writeDetailedLog(`שגיאה בבדיקת סטטוס בקבוצה ${groupName}: ${error.message}`, 'ERROR');
    return {
      groupName: groupName,
      groupUrl: groupUrl,
      statusUrl: statusUrl,
      posts: [],
      scanTime: new Date().toISOString(),
      success: false,
      error: error.message
    };
  }
}

// פונקציה לשמירת התוצאות
function saveResults(results) {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = `groups-post-status-${timestamp.slice(0, 10)}.json`;
    
    const dataToSave = {
      scanDate: new Date().toISOString(),
      totalGroups: results.length,
      successfulScans: results.filter(r => r.success).length,
      failedScans: results.filter(r => !r.success).length,
      results: results
    };
    
    // שמירה מקומית
    fs.writeFileSync(fileName, JSON.stringify(dataToSave, null, 2));
    writeDetailedLog(`נתונים נשמרו ב: ${fileName}`, 'SUCCESS');
    
    // שמירה נוספת בשם קבוע לקריאה קלה
    fs.writeFileSync('latest-groups-post-status.json', JSON.stringify(dataToSave, null, 2));
    writeDetailedLog('נתונים נשמרו גם ב: latest-groups-post-status.json', 'SUCCESS');
    
    // יצירת דוח מסכם
    const summary = {
      scanDate: dataToSave.scanDate,
      totalGroups: dataToSave.totalGroups,
      summary: {
        published: 0,
        pending: 0,
        rejected: 0,
        removed: 0,
        unknown: 0
      }
    };
    
    results.forEach(group => {
      group.posts.forEach(post => {
        if (post.status.includes('בהצלחה') || post.status.includes('published')) {
          summary.summary.published++;
        } else if (post.status.includes('בהמתנה') || post.status.includes('pending')) {
          summary.summary.pending++;
        } else if (post.status.includes('נדחה') || post.status.includes('rejected') || post.status.includes('declined')) {
          summary.summary.rejected++;
        } else if (post.status.includes('הוסר') || post.status.includes('removed')) {
          summary.summary.removed++;
        } else {
          summary.summary.unknown++;
        }
      });
    });
    
    fs.writeFileSync('groups-post-status-summary.json', JSON.stringify(summary, null, 2));
    writeDetailedLog('דוח מסכם נשמר ב: groups-post-status-summary.json', 'SUCCESS');
    
    return fileName;
    
  } catch (error) {
    writeDetailedLog(`שגיאה בשמירת תוצאות: ${error.message}`, 'ERROR');
    return null;
  }
}

// פונקציה לשליחת התוצאות לשרת
async function uploadResults(data) {
  try {
    writeDetailedLog('מתחיל שליחת נתונים לשרת...', 'INFO');
    
    const instanceName = fs.readFileSync(path.join(__dirname, 'instance-name.txt'), 'utf-8').trim();
    
    const uploadData = {
      instance: instanceName,
      scanType: 'groups-post-status',
      data: data
    };
    
    const fetch = require('node-fetch');
    const response = await fetch('https://postify.co.il/wp-content/postify-api/save-groups-status.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(uploadData)
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const result = await response.json();
    writeDetailedLog(`נתונים נשלחו בהצלחה לשרת: ${result.message || 'OK'}`, 'SUCCESS');
    return true;
    
  } catch (error) {
    writeDetailedLog(`שגיאה בשליחת נתונים לשרת: ${error.message}`, 'ERROR');
    return false;
  }
}

// פונקציה ראשית
(async () => {
  writeDetailedLog('מתחיל סקריפט בדיקת סטטוס פרסומים בקבוצות...', 'START');
  
  // עיבוד פרמטרי command line
  const args = process.argv.slice(2);
  let targetDate = null;
  let specificGroupUrl = null;
  
  args.forEach(arg => {
    if (arg.startsWith('--date=')) {
      targetDate = arg.split('=')[1];
      writeDetailedLog(`פרמטר תאריך: ${targetDate}`, 'INFO');
    } else if (arg.startsWith('--group=')) {
      specificGroupUrl = arg.split('=')[1];
      writeDetailedLog(`פרמטר קבוצה ספציפית: ${specificGroupUrl}`, 'INFO');
    }
  });
  
  try {
    let todayGroups = [];
    
    if (specificGroupUrl) {
      // סריקת קבוצה ספציפית
      todayGroups = [{
        name: 'קבוצה ספציפית',
        url: specificGroupUrl,
        postFile: 'manual',
        postTitle: 'בדיקה ידנית'
      }];
      writeDetailedLog(`מבצע סריקה לקבוצה ספציפית: ${specificGroupUrl}`, 'INFO');
    } else {
      // שלב 1: חיפוש קבוצות שפורסמו בתאריך המבוקש
      todayGroups = getTodayPublishedGroups(targetDate);
    }
    
    if (todayGroups.length === 0) {
      const dateMsg = targetDate ? `בתאריך ${targetDate}` : 'היום';
      writeDetailedLog(`לא נמצאו קבוצות שפורסמו אליהן ${dateMsg}`, 'WARNING');
      process.exit(0);
    }
    
    writeDetailedLog(`נמצאו ${todayGroups.length} קבוצות לבדיקה`, 'INFO');
    
    // שלב 2: הגדרת דפדפן
    writeDetailedLog('מפעיל דפדפן...', 'INFO');
    const userDataDir = config.userDataDir.replace("user", os.userInfo().username);
    
    const browser = await puppeteer.launch({
      headless: false,
      executablePath: config.chromePath,
      userDataDir: userDataDir,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--window-size=1280,800",
        "--profile-directory=Default",
        "--start-maximized"
      ]
    });
    
    const pages = await browser.pages();
    const page = pages.length > 0 ? pages[0] : await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });
    
    writeDetailedLog('דפדפן הופעל בהצלחה', 'SUCCESS');
    
    // שלב 3: סריקת כל הקבוצות
    const results = [];
    
    for (let i = 0; i < todayGroups.length; i++) {
      const group = todayGroups[i];
      writeDetailedLog(`מעבד קבוצה ${i + 1}/${todayGroups.length}: ${group.name}`, 'INFO');
      
      const result = await checkPostStatusInGroup(page, group.url, group.name);
      result.postFile = group.postFile;
      result.postTitle = group.postTitle;
      
      results.push(result);
      
      // המתנה בין קבוצות
      if (i < todayGroups.length - 1) {
        writeDetailedLog('ממתין 2 שניות לפני המעבר לקבוצה הבאה...', 'DEBUG');
        await new Promise(res => setTimeout(res, 2000));
      }
    }
    
    // שלב 4: שמירת תוצאות
    writeDetailedLog('שומר תוצאות...', 'INFO');
    const savedFile = saveResults(results);
    
    if (savedFile) {
      writeDetailedLog(`סריקה הושלמה בהצלחה! תוצאות נשמרו ב: ${savedFile}`, 'SUCCESS');
      
      // שליחת נתונים לשרת
      const dataToUpload = {
        scanDate: new Date().toISOString(),
        totalGroups: results.length,
        successfulScans: results.filter(r => r.success).length,
        failedScans: results.filter(r => !r.success).length,
        results: results
      };
      
      await uploadResults(dataToUpload);
    }
    
    // שלב 5: הצגת סיכום
    const successfulScans = results.filter(r => r.success).length;
    const totalPosts = results.reduce((sum, r) => sum + r.posts.length, 0);
    
    writeDetailedLog(`סיכום: ${successfulScans}/${results.length} קבוצות נסרקו בהצלחה`, 'SUCCESS');
    writeDetailedLog(`נמצאו ${totalPosts} פוסטים מהיום`, 'SUCCESS');
    
    // סגירת דפדפן
    writeDetailedLog('סוגר דפדפן...', 'INFO');
    await browser.close();
    writeDetailedLog('דפדפן נסגר בהצלחה', 'SUCCESS');
    
  } catch (error) {
    writeDetailedLog(`שגיאה קריטית: ${error.message}`, 'CRITICAL');
    writeDetailedLog(`פרטי השגיאה: ${error.stack}`, 'CRITICAL');
    process.exit(1);
  }
})();
