module.exports = {
  user: "postify.user@gmail.com",         // כתובת המייל השולחת
  pass: "tkfa umxa zofy dwwi",         // סיסמת אפליקציה (לא רגילה!)
  to: "yehiad82@gmail.com",               // כתובת היעד שתקבל התראות
  errorTo: "postify.user@gmail.com"        // מייל לקבלת שגיאות מערכת
};
