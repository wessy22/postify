const logToSheet = require('./log-to-sheets');

logToSheet('⚙️ Test Log', 'Success', 'Groupify', 'בדיקה ראשונית');
